package usp.poo.ex6;

public interface Calculador {
    public void calcular(Integer[] a, Integer[] b);
}
